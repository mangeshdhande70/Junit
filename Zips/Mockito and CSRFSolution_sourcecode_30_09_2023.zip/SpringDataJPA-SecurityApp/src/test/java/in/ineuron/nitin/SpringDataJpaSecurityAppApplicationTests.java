package in.ineuron.nitin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaSecurityAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
