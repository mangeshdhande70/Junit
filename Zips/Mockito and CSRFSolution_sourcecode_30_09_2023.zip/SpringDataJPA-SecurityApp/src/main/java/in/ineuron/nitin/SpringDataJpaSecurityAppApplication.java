package in.ineuron.nitin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaSecurityAppApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaSecurityAppApplication.class, args);
	}

}
